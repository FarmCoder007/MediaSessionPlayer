package com.lazy.mediasessiontest;

/**
 * author : xu
 * date : 2021/2/24 16:43
 * description :
 */
public abstract class PlaybackInfoListener {

    public abstract void onPlaybackStateChange(PlaybackStateCompat state);

    public void onPlaybackCompleted() {
    }
}
